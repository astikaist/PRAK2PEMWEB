<?php
//case sensitif
/*echo "Universitas Sebelas Maret<br>";
Echo "Universitas Sebelas Maret<br>";
ecHo "Universitas Sebelas Maret<br>";

$prodi ="informatika";
echo "Prodi Saya $prodi<br>";
echo "Prodi teman Saya di".$prodi."<br>";*/

/*$x=100;
$y=92;

function perta,bahan(){
	$GLOBALS['a'] = $GLOBALS['x'] + $GLOBALS['y'];
}

var_dump(pertambahan());

pertambahan();
echo $a;

//echo$x+$y;*/

//get untuk data biasa
//post untuk password dll, mendukung inputan multiple
/*<html>
<form action="respon_form.php" method="get">
Nama: <input type="text" name="nama"><br>
Prodi : <input type="text" name="prodi"><br>
<input type="submit">
</form>
</html>*/

/*$hari=date("d");

var_dump($hari);

if ($hari<"10"){
	echo "awal bulan";
}
else if ($hari>"20"){
	echo "akhir bulan";
}
else{
	echo "pertengahan bulan";
}

//jika ada banyak case agar tidak terlalu banyak memakai if else, maka digunakan case
$meletus="hijau";

switch($meletus){
	case "hijau";
		echo "";
		break;
	case "kuning";
		echo "";
		break;
	case "kelabu";
		echo "dur";
		break;
	default:
		echo "balonku masih utuh";
}*/

//looping
/*$w=99;

while($w <= 100){
	echo "anda kurang senilai $w <br>";
	$w++;
}
do {
	echo "nilai yang lulus adalah $w <br>";
	$w++;
}while ($w <= 100);*/

//array
/*$kelas = array("satu", "dua", "tiga");
$room= ["empat", "lima", "enam"];

var_dump($kelas);
//echo $kelas[1];
echo $kelas ."<br>". $roo,[0];
foreach($kelas as $k){
	echo $k. "<br>";
}*/

//multi dimensi array
$kelas=[["satu"],["dua"],["tiga"]];
//echo $kelas [1][0];
var_dump($kelas);
?>