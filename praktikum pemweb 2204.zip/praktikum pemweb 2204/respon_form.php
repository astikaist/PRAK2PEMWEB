Selamat <?php echo $_GET["nama"]; ?><br>
anda adalah <?php echo $_GET["prodi"];?>